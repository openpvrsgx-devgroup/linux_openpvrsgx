<?php
$sdvoDtdCount = 1;
$lvdsDtdCount = 1;
    if(count($_POST) > 0)
    {
        if ($handle = opendir($_POST["source"]))
        {
                $count = 0;
                $passCount = 0;
                $failCount = 0;
                
                $fh = fopen($_POST["target"]."TestReport.txt", 'w');
                $summaryString = "Test Report\nTest Summary:\$TestSummary\$\nTest Date:".date(r)."\n";
                $summaryString = $summaryString."Instructions for:\nWarnings: Validation Tool does not validate some of the chosen controls. Change the test case to include only those controls which are validated by the tool.\nFail: Please create a HSD. Attach the input file and output file of the failed Tests and also attach this test report to it.\n\n\n";
                
            while (false !== ($file = readdir($handle))) {
                if ($file != "." && $file != "..") {
                    $sdvoDtdCount = 1;
                    $lvdsDtdCount = 1;
                    $warningArray = array();
                    $fp = fopen($_POST["source"].$file, 'r');
                    $cookieStr = fread($fp, filesize($_POST["source"].$file));
                    $cookieValues = explode("|", $cookieStr);
                    $configValues = validate($cookieValues, $warningArray);
                    //fwrite($fh, print_r($sdvoDtdCount." ".$lvdsDtdCount, true));
                    $confFile = @fopen($_POST["target"].$file."_xorg.conf", "r");
                    $pass = true;
                    $mismatches = "";
                    $warnings = "";
                    
                    if ($confFile)
                    {
                        while (!feof($confFile))
                        {
                            $matches = "";
                            $buffer = fgets($confFile);
                            if(strpos($buffer,"Option") !== FALSE && strpos($buffer,"ALL") !== FALSE)
                            {
                                for($j = 0; $j<count($configValues); $j++)
                                {
                                    if(strpos($buffer, $configValues[$j]->configname."") !== FALSE)
                                    {
                                        if(strpos($buffer, "\"".$configValues[$j]->configvalue."\"") !== FALSE)
                                        {
                                            $matches = $buffer;
                                            break;
                                        }
                                    }
                                    
                                    if(in_array($configValues[$j]->configname."", $warningArray))
                                    {
                                        if(strpos($warnings, $configValues[$j]->configname."") === false)
                                        {
                                            $warnings = $warnings.$configValues[$j]->configname." ".$configValues[$j]->warningmessage."\n";
                                        }
                                        $matches = "warning";
                                    }
                                    
                                }
                                $pass = $pass && ($matches != "");
                                if($matches === "")
                                {
                                    $mismatches = $mismatches.$buffer."\n";
                                }
                            }
                        }
                        fclose($confFile);
                    }
                    $summaryString = $summaryString."Test ".($count+1).":\n";
                    $summaryString = $summaryString."Input File: ".$file."\n";
                    $summaryString = $summaryString."Output File: ".$file."_xorg.conf\n";
                    if($pass)
                    {
                        $summaryString = $summaryString."Result: Pass\n";
                        if($warnings != "")
                        {
                            //$summaryString = $summaryString."Summary:\n";                        
                            $summaryString = $summaryString."Warnings:\n".$warnings;
                        }
                        $passCount++;
                    }
                    else
                    {
                        $summaryString = $summaryString."Result: fail\n";
                        //$summaryString = $summaryString."Summary:\n";
                        $summaryString = $summaryString."Mismatches at:\n".$mismatches;
                        $failCount++;
                    }
                    $count++;
                    $summaryString = $summaryString."\n\n";
                    fclose($fp);
                }
            }
            $summaryString = str_replace("\$TestSummary\$","Number of Tests ".$count.", Passed ".$passCount.", Failed ".$failCount,$summaryString);
            fwrite($fh, $summaryString);
            fclose($fh);
        }                
    }
    
    function validate($cookieArray, &$warningArray)
    {
        global $sdvoDtdCount, $lvdsDtdCount;
        
        $xml = openValidationXML();
        $returnValues = array();
        $displayMode = "";
        $primaryDisplay  = "";
        $ifedid = new stdClass();
        $ifedid->configvalue = 0;
        $ifnotedid = new stdClass();
        $ifnotedid->configvalue = 0;
        $sdvoifedid = new stdClass();
        $sdvoifedid->configvalue = 0;
        $sdvoifnotedid = new stdClass();
        $sdvoifnotedid->configvalue = 0;
        $defaultedid = true;
        $sdvodefaultedid = true;
        
        $ifedid->configname = xPathMapping($xml, "lvds_edid_usestandardtimings", "1")->configitem[0]->configname."";
        $ifnotedid->configname = xPathMapping($xml, "lvds_notedid_usestandardtimings", "1")->configitem[0]->configname."";
        
        $sdvoifedid->configname = xPathMapping($xml, "sdvo_edid_usestandardtimings", "1")->configitem[0]->configname."";
        $sdvoifnotedid->configname = xPathMapping($xml, "sdvo_notedid_usestandardtimings", "1")->configitem[0]->configname."";
        
        $lvdsColorCorrection = new stdClass();
        $lvdsColorCorrection->configitem = array();
        $lvdsColorCorrection->configitem[0]->configname = "ALL/1/Port/4/Attr/35";
        $lvdsColorCorrection->configitem[0]->configvalue = "0x000000";
        $lvdsColorCorrection->configitem[1]->configname = "ALL/1/Port/4/Attr/36";
        $lvdsColorCorrection->configitem[1]->configvalue = "0x808080";
        $lvdsColorCorrection->configitem[2]->configname = "ALL/1/Port/4/Attr/37";
        $lvdsColorCorrection->configitem[2]->configvalue = "0x808080";
        
        $sdvoColorCorrection = new stdClass();
        $sdvoColorCorrection->configitem[0]->configname = "ALL/1/Port/2/Attr/35";
        $sdvoColorCorrection->configitem[0]->configvalue = "0x000000";
        $sdvoColorCorrection->configitem[1]->configname = "ALL/1/Port/2/Attr/36";
        $sdvoColorCorrection->configitem[1]->configvalue = "0x808080";
        $sdvoColorCorrection->configitem[2]->configname = "ALL/1/Port/2/Attr/37";
        $sdvoColorCorrection->configitem[2]->configvalue = "0x808080";
        
        for($i=0;$i<count($cookieArray);$i++)
        {
            
            $settingStr = $cookieArray[$i];
            $settingNameValue = explode("=",$settingStr);
            $values = xPathMapping($xml, $settingNameValue[0], $settingNameValue[1]);
            
            if($values == null && strpos($settingNameValue[0],"_dtds") !== FALSE)
            {        
                $query = "//mapping[@type=\"dtd\"]";
                $dtds = openValidationXML()->xpath($query);
                for($l=0;$l<count($dtds);$l++)
                {
                    if((strpos($dtds[$l]->attributes()->settingname."","lvds") !== FALSE && strpos($settingNameValue[0], "lvds") !== FALSE) ||
                       (strpos($dtds[$l]->attributes()->settingname."","sdvo") !== FALSE && strpos($settingNameValue[0], "sdvo") !== FALSE))
                    {
                        $dtd = $dtds[$l];
                        break;
                    }
                }
                
                
                dtdWarning($dtd, $settingNameValue[0], $warningArray, $returnValues);
                
            }
            
            if($settingNameValue[0] == "global_cbo_primary_display")
                $primaryDisplay = $settingNameValue[1];
                
            validateEdid($settingNameValue, $edidOption, $ifedid, $ifnotedid, $defaultedid, $values, "lvds");
            validateEdid($settingNameValue, $sdvoedidOption, $sdvoifedid, $sdvoifnotedid, $sdvodefaultedid, $values, "sdvo");
            
            validateColorCorrection($settingNameValue, $lvdsColorCorrection, $values, "lvds", $warningArray);
            validateColorCorrection($settingNameValue, $sdvoColorCorrection, $values, "sdvo", $warningArray);
                        
            if(strpos($settingNameValue[0],"_nostandardtimings") == false && strpos($settingNameValue[0], "_noEDID") == false && strpos($settingNameValue[0], "_edid_usestandardtimings" ) == false &&
               strpos($settingNameValue[0], "_edid_useedidblock") == false && strpos($settingNameValue[0], "_edid_useuserdefined") == false && strpos($settingNameValue[0], "_notedid_usestandardtimings") == false
               && strpos($settingNameValue[0], "_notedid_useuserdefined") == false && strpos($settingNameValue[0], "_edid_option") == false && strpos($settingNameValue[0], "ValueGamma") == false && strpos($settingNameValue[0], "ValueBright") == false && strpos($settingNameValue[0], "ValueContrast") == false)
            {
                for($j=0;$j<count($values);$j++)
                {
                    if($values->configitem[$j]->configname == "ALL/1/name")
                        $displayMode = $values->configitem[$j]->configvalue;
                    $returnValues[] = $values->configitem[$j];           
                }
            }
        }
        
        if($defaultedid)
        {
            $ifedid->configvalue = 7;
            $ifnotedid->configvalue = 5;
        }
        if($sdvodefaultedid)
        {
            $sdvoifedid->configvalue = 7;
            $sdvoifnotedid->configvalue = 5;
        }
        
        $edid = new stdClass();        
        $edid->configname = "ALL/1/Port/4/General/Edid";
        $edid->configvalue = $ifedid->configvalue == 0?0:1;
        $returnValues[] = $edid;
        
        $sdvoedid = new stdClass();
        $sdvoedid->configname = "ALL/1/Port/2/General/Edid";
        $sdvoedid->configvalue = $sdvoifedid->configvalue == 0?0:1;
        $returnValues[] = $sdvoedid;
        
        $returnValues[] = $ifedid;
        $returnValues[] = $ifnotedid;
        $returnValues[] = $sdvoifedid;
        $returnValues[] = $sdvoifnotedid;
        
        for($k=0;$k<count($lvdsColorCorrection->configitem);$k++)
        {
            $returnValues[] = $lvdsColorCorrection->configitem[$k];
        }
        for($k=0;$k<count($sdvoColorCorrection->configitem);$k++)
        {
            $returnValues[] = $sdvoColorCorrection->configitem[$k];
        }
        
        $returnValues = array_merge($returnValues, setPortOrder($displayMode, $primaryDisplay));
        return $returnValues;
    }
    
    function dtdWarning($dtd, $settingname, &$warningArray, &$returnValues)
    {
        global $sdvoDtdCount, $lvdsDtdCount;
        for($m=0;$m<count($dtd->configitem);$m++)
        {
            if(!in_array($dtd->configitem[$m]->configname, $warningArray))
            {                        
                if(strpos($settingname, "sdvo") !== FALSE)
                    $dtd->configitem[$m]->configname = str_replace("?",$sdvoDtdCount,$dtd->configitem[$m]->configname);
                if(strpos($settingname, "lvds") !== FALSE)
                    $dtd->configitem[$m]->configname = str_replace("?",$lvdsDtdCount,$dtd->configitem[$m]->configname);
                    
                $returnValues[] = $dtd->configitem[$m];
                $warningArray[count($warningArray)]=$dtd->configitem[$m]->configname;
            }                            
        }
        
        if(strpos($settingname, "sdvo") !== FALSE)
            $sdvoDtdCount++;
        if(strpos($settingname, "lvds") !== FALSE)
            $lvdsDtdCount++;
    }
    
    function validateEdid($settingNameValue, &$edidOption, &$ifedid, &$ifnotedid, &$defaultedid, $values, $prefix)
    {
        if($settingNameValue[0] == $prefix."_edid_option")
        {
            $edidOption = $settingNameValue[1];
        }
            
        if($edidOption == $prefix."_SimpleEDID")
        {
            if($settingNameValue[0] == $prefix."_nostandardtimings")
            {
                $ifedid->configvalue = 7 - intval($values->configitem[0]->configvalue."");
                $ifnotedid->configvalue = 5 - intval($values->configitem[1]->configvalue."");
                $defaultedid = false;
            }
            elseif($settingNameValue[0] == $prefix."_noEDID")
            {
                $ifedid->configvalue = 0;
                if($ifnotedid->configvalue == 0)
                {
                    $ifnotedid->configvalue = 5;
                }
                $defaultedid = false;
            }  
        }
        else
        {
            if($settingNameValue[0] == $prefix."_edid_usestandardtimings" || $settingNameValue[0] == $prefix."_edid_useedidblock" || $settingNameValue[0] == $prefix."_edid_useuserdefined")
            {
                $ifedid->configvalue = $ifedid->configvalue + intval($values->configitem[0]->configvalue."");
                $defaultedid = false;
            }
            elseif($settingNameValue[0] == $prefix."_notedid_usestandardtimings" || $settingNameValue[0] == $prefix."_notedid_useuserdefined")
            {
                $ifnotedid->configvalue = $ifnotedid->configvalue + intval($values->configitem[0]->configvalue."");
                $defaultedid = false;
            }                
        }
    }
    
    function validateColorCorrection($settingsNameValue, &$colorCorrection, $values, $prefix, &$warningArray)
    {
        if(strpos($settingsNameValue[0],"Overlay") == FALSE)
        {
            for($i=0;$i<count($colorCorrection->configitem);$i++)
            {
                if($colorCorrection->configitem[$i]->configname."" == $values->configitem[0]->configname."")
                {
                    if($settingsNameValue[0][strlen($settingsNameValue[0])-1] == "R")
                    {        
                        $pos = 2;
                    }
                    else if($settingsNameValue[0][strlen($settingsNameValue[0])-1] == "G")
                    {
                        $pos = 4;
                    }
                    else if($settingsNameValue[0][strlen($settingsNameValue[0])-1] == "B")
                    {
                        $pos = 6;
                    }
                    
                       
                    $colorCorrection->configitem[$i]->configvalue = substr_replace($colorCorrection->configitem[$i]->configvalue,
                                                                                   $values->configitem[0]->configvalue,$pos,2);
                    $colorCorrection->configitem[$i]->warningmessage = $values->configitem[0]->warningmessage;
                                  
                }
            }
            
            if((strpos($settingsNameValue[0], "Gamma") !== FALSE && ($settingsNameValue[1] == "0.6" || $settingsNameValue[1] == "6")) || ((strpos($settingsNameValue[0], "Bright") !== FALSE || strpos($settingsNameValue[0], "Contrast") !== FALSE) && ($settingsNameValue[1] == "-127" || $settingsNameValue[1] == "127")))
                return true;
            else if(strpos($settingsNameValue[0], "Gamma") == FALSE && strpos($settingsNameValue[0], "Bright") == FALSE && strpos($settingsNameValue[0], "Contrast") == FALSE)
                return true;
            else
            {
                if(!in_array($values->configitem[0]->configname, $warningArray))
                    $warningArray[count($warningArray)]=$values->configitem[0]->configname;
                return false;
            }
        }
        else
        {
            if(!((strpos($settingsNameValue[0], "Gamma") !== FALSE && ($settingsNameValue[1] == "0.6" || $settingsNameValue[1] == "3" || $settingsNameValue[1] == "6")) || ((strpos($settingsNameValue[0], "Overlay2") !== FALSE || strpos($settingsNameValue[0], "Overlay3") !== FALSE || strpos($settingsNameValue[0], "Overlay4") !== FALSE) && ($settingsNameValue[1] == "0" || $settingsNameValue[1] == "100" || $settingsNameValue[1] == "200"))))
            {
                if(!in_array($values->configitem[0]->configname, $warningArray))
                        $warningArray[count($warningArray)]=$values->configitem[0]->configname;
                return false;
            }
        }
    }
    
    function setPortOrder($displayMode, $primaryDisplay)
    {
        $configItemArray = array();
        $configitem = new stdClass();
        $configitem->configname = "ALL/1/General/PortOrder";
        if($displayMode == "single")
        {
            if($primaryDisplay == "LVDS")
                $configitem->configvalue = 40000;
            else if($primaryDisplay == "sDVO")
                $configitem->configvalue = 20000;
        }
        else
        {
            $secondaryDisplayItem = new stdClass();
            if($primaryDisplay == "LVDS")
            {
                $secondaryDisplayItem->configname = "2/General/name";
                $secondaryDisplayItem->configvalue = "sdvo";
                $configitem->configvalue = 42000;
            }
            else if($primaryDisplay == "sDVO")
            {
                $secondaryDisplayItem->configname = "4/General/name";
                $secondaryDisplayItem->configvalue = "lvds";
                $configitem->configvalue = 24000;
            }
            $configItemArray[] = $secondaryDisplayItem;
        }
        $configItemArray[] = $configitem;
        return $configItemArray;
    }
    
    function openValidationXML()
    {
        $xml = null;
        if (file_exists('validationmapping.xml'))
        {
            $xml=simplexml_load_file('validationmapping.xml');
        }
        else
            echo "no file";
            
        return $xml;
    }
    
    function xPathMapping($xml, $settingname, $settingvalue)
    {
        global $sdvoDtdCount, $lvdsDtdCount;
        if($xml == null)
            $xml = openValidationXML();
        $query = "//mapping[@settingname=\"".$settingname."\" and @settingvalue=\"".$settingvalue."\"]";
        $val = $xml->xpath($query);
        if($val == null)
        {
            $query = "//mapping[@settingname=\"".$settingname."\"]";
            $val = $xml->xpath($query);
            if($val != null)
                $val[0]->configitem[0]->configvalue = $settingvalue;
        }
        
        if(strpos($settingname, "_dtds_") !== FALSE && $val[0] != null)
        {
            $val[0] = handleDTDMapping($val[0], $settingname);
        }
        
        return $val[0];
    }
    
    function handleDTDMapping($val, $settingname)
    {
        global $lvdsDtdCount, $sdvoDtdCount;
        
        for($i=0;$i<count($val->configitem);$i++)
        {
            if(strpos($settingname, "sdvo") !== FALSE)
                $val->configitem[$i]->configname = str_replace("?",$sdvoDtdCount,$val->configitem[$i]->configname);
            if(strpos($settingname, "lvds") !== FALSE)
                $val->configitem[$i]->configname = str_replace("?",$lvdsDtdCount,$val->configitem[$i]->configname);
        }
        if(strpos($settingname, "sdvo") !== FALSE)
            $sdvoDtdCount++;
        if(strpos($settingname, "lvds") !== FALSE)
            $lvdsDtdCount++;
            
        return $val;
    }
    
?>