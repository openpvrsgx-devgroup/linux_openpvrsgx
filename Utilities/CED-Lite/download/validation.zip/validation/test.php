<html>
    <head>
        <script type="text/javascript" src="../scripts/jquery.js"></script>
          <script type="text/javascript">
    <?php
    
        echo "function onLoad(){";
        if(count($_GET) > 0)
        {
            
            if ($handle = opendir($_GET["settingsFile1"])) {
                   $count = 0;
                while (false !== ($file = readdir($handle))) {
                    //echo "$file\n";
                    if ($file != "." && $file != "..") {
                        $sourceFolder = str_replace("\\","\\\\",$_GET["settingsFile1"])."\\\\";
                        $fullPath = str_replace("\\","\\\\",$_GET["settingsFile1"])."\\\\".$file;
                        $xorgFolder = str_replace("\\","\\\\",$_GET["xorgFolder"])."\\\\";
                        $fh = fopen($fullPath, 'r');
                        $theData = fread($fh, filesize($fullPath));
                        fclose($fh);

                        echo "saveData(\"$file\",\"$theData\",\"$xorgFolder\", \"$sourceFolder\", $count);";
                        $count++;
                    }
                }
                closedir($handle);
                echo "beginTest();";
            }
        }
        echo "}";
    ?>
    
       
        var genCount = 0;
        
        var fileContentsArray = new Array();
        var fileArray = new Array();
        var targetName = "";
        var WREF;
        var sourceFolder = "";
        
        function saveData(file, fileContents, targetFolder, source, count)
        {
            fileContentsArray[count] = fileContents;
            fileArray[count] = file;
            targetName = targetFolder;
            sourceFolder = source;
        }
        
        function beginTest()
        {
            WREF = window.open("../index.html","cedlite");
            if(!WREF.opener){ WREF.opener = this.window; }
            
            setTimeout("generate()",5000);
        }
        
        function generate()
        {
            var fileContents = fileContentsArray[genCount];
            WREF.testing = true;            
            WREF.loadSelections(fileContents);
            var xorgStr = WREF.generate();
            
            $.post("autoconfgen.php", { xorg: xorgStr, target: targetName, fileName: fileArray[genCount] } );
            genCount++;
            WREF.close();
            if(genCount < fileArray.length)
                beginTest();
            else
                validate();
                //document.getElementById("validate").style.display = "";
        }
        
        function validate()
        {
            $.post("validate.php", {target: targetName, source: sourceFolder});
            alert("Validation Completed");
        }
        
        </script>
    </head>
    <body onload="onLoad();">
        <?php
        if(!(count($_GET) > 0))
        {
            echo '<form action="test.php" method="get">
                <div>Settings Folder <input type="text" NAME="settingsFile1" id="settingsFile1" size="70"></div>
                <div>Configuration Folder<input type="text" NAME="xorgFolder" id="xorgFolder" size="70"></div>
                <input type="submit" value="Begin Test">';
        }
        else
        {
            echo '<input id="validate" type="button" value="Validate" style="display:none" onclick="validate();"/>';
        }
        ?>
        </form>
    </body>
</html>