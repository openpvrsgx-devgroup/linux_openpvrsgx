<?php
        if(count($_POST) > 0)
        {
            $fp = fopen($_POST["target"].$_POST["fileName"]."_xorg.conf", 'w');
            fwrite($fp, $_POST["xorg"]);
            fclose($fp);
        }
?>